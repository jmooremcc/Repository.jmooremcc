from resources.lib.KodiLib.KodiUtilities import *


# st=getBroadcast_startTime(kodiObj, 4.1, "price is right")
# st=getBroadcast_startTime(kodiObj, 33.1, "Big Bang Theory")
# print(st)
cn = changeChannelByChannelNumber(kodiObj, 6)
pass
