
from datetime import timedelta, datetime, date
import time

__Version__ = "1.0.0"

def isleap(year):
    if year % 4 == 0:
        if year % 100 == 0:
            if year % 400 == 0:
                return True

    return False

def nextmonth(date:datetime):
    one_day = timedelta(days=1)
    tt = date.timetuple()
    month = tt.tm_mon + 1
    ttl = list(tt)
    if month > 12:
        month = 1

    ttl[1] = month
    td = datetime.fromtimestamp(time.mktime(tuple(ttl)))
    while td.month != month:
        td = td - one_day

    return td
