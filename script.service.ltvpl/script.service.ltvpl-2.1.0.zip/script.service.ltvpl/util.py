#
#       Copyright (C) 2018
#       John Moore (jmooremcc@hotmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import os
import sys
from datetime import datetime

from resources.lib.Utilities.DebugPrint import DbgPrint

__Version__ = "1.1.4"


def GetXBMCVersion():
    version = xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')
    version = version.split('.')
    return int(version[0]), int(version[1]) #major, minor



ADDON   =  xbmcaddon.Addon()
ADDONID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_USERDATA_FOLDER = xbmcvfs.translatePath("special://profile/addon_data/"+ADDONID)
BASEPATH = os.path.join(ADDON_PATH,r"resources")
DATAFILE_LOCATIONFILE = os.path.join(BASEPATH, r"data/dataFileLocation.py")
ADDON_DATAFILENAME = os.path.join(ADDON_USERDATA_FOLDER,"LTVPL.pkl")
DEFAULTPATH ='dataFilePath = r"' + ADDON_DATAFILENAME + '"'
DEBUGFILE_LOCATIONFILE = os.path.join(BASEPATH, r"data/debugFileLocation.py")
DEBUGFILE_DEFAULTPATH = os.path.join(BASEPATH, r"data/debugcache.json")
DEBUGFILE_LOCATIONCONTENT = 'DEBUGCACHEFILE = r"' + DEBUGFILE_DEFAULTPATH + '"'
XMLPATH = os.path.join(ADDON_PATH, 'resources/skins/Default/720p')
FANART_PATH = os.path.join(ADDON_PATH, 'ltvpl-fanart.jpg')
BGDIMAGE = os.path.join(ADDON_PATH, 'resources/skins/Default/media', 'ltvpl-WhiteBlank.png')

HOME    =  ADDON_PATH
ROOT    =  ADDON.getSetting('FOLDER')
PROFILE =  os.path.join(ROOT, 'ltvpl')
VERSION = '1.0.0'
ICON    =  os.path.join(HOME, 'ltvpl-icon.png')
FANART  =  os.path.join(HOME, 'ltvpl-fanart.jpg')
SEARCH  =  os.path.join(HOME, 'resources', 'media', 'search.png')
# GETTEXT =  ADDON.getLocalizedString
LTVPL_HEADER = LTVPL = 'Live TV Playlist'

ACTIVATIONKEY = 'activationkey'

def GETTEXT(id):
    return ADDON.getLocalizedString(id)

def getRegionDatetimeFmt():
    timefmt = xbmc.getRegion('time')
    timefmt = timefmt.replace(':%S','')

    if "%I%I" in timefmt:
        timefmt = timefmt.replace('%I%I', "%I")
    elif "%H%H" in timefmt:
        timefmt = timefmt.replace('%H%H', "%H")

    return xbmc.getRegion('dateshort') + " " + timefmt

def setUSpgmDate(obj):
    try:
        dateformat = xbmc.getRegion('dateshort')
        pgmDate = obj.getProperty('pgmDate')
        liDateTime = datetime.strptime(pgmDate, dateformat)
        USpgmDate = liDateTime.strftime("%m/%d/%Y")
        obj.setProperty('USpgmDate', USpgmDate)
    except Exception as e:
        DbgPrint(e)

def DialogOK(title, line1, line2='', line3=''):
    d = xbmcgui.Dialog()
    d.ok(title + ' - ' + VERSION, line1, line2 , line3)


def DialogYesNo(title, line1, line2='', line3='', noLabel=None, yesLabel=None):
    d = xbmcgui.Dialog()
    if noLabel is None or yesLabel is None:
        return d.yesno(title + ' - ' + VERSION, line1, line2 , line3) == True
    else:
        return d.yesno(title + ' - ' + VERSION, line1, line2 , line3, noLabel, yesLabel) == True


def generateMD5(text):
    if not text:
        return ''

    try:
        import hashlib
        return hashlib.md5(text).hexdigest()
    except Exception as e:
        DbgPrint(e)
        try:
            import md5
            return md5.new(text).hexdigest()
        except Exception as e:
            DbgPrint(e)

    return '0'

def GetFolder(title):
    default = ROOT #ADDON.getAddonInfo('profile')
    folder  = xbmcvfs.translatePath(PROFILE)

    if not os.path.isdir(folder):
        os.makedirs(folder)

    folder = xbmcgui.Dialog().browse(3, title, 'files', '', False, False, default)
    if folder == default:
        return None

    return xbmcvfs.translatePath(folder)
