import sys
from .lib import *

if sys.version[0] == '2':
    from enum import *
