#
#       Copyright (C) 2018
#       John Moore (jmooremcc@hotmail.com)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import os, sys
import xbmc
import xbmcgui
import xbmcaddon

#from logger import logxbmc.log("***path")

# print str(sys.path)
myLog = xbmc.log

from util import ADDON, ADDON_PATH, ADDONID, ADDON_USERDATA_FOLDER, BASEPATH, DATAFILE_LOCATIONFILE, ADDON_DATAFILENAME,\
    DEFAULTPATH, DEBUGFILE_LOCATIONFILE, DEBUGFILE_LOCATIONCONTENT, ENUMPATH
from resources.lib.Network.SecretSauce import ServerPort, ServerHost
from resources.PL_Server import PL_Server
import Countdown

xbmc.log("***sys.path: "+str(sys.path))

LTVPL = 'Live TV Playlist'

LocalOperationFlag = False
#SETTINGS
VACATIONMODE='vacationmode'
PREROLLTIME='preroll_time'
DAILYSTOPCOMMAND='dailystopcommand'

def establishDataLocations():
    if not os.path.exists(ADDON_USERDATA_FOLDER):
        xbmc.log("LTVPL: Making addonUserDataFolder")
        try:
            os.mkdir(ADDON_USERDATA_FOLDER)
        except:
            pass
    else:
        xbmc.log("LTVPL: addonUserDataFolder Exists")

    #Data File
    fs = open(DATAFILE_LOCATIONFILE,'w')
    fs.write(DEFAULTPATH)
    fs.close()
    #

    # Debug File
    fs = open(DEBUGFILE_LOCATIONFILE, 'w')
    fs.write(DEBUGFILE_LOCATIONCONTENT)
    fs.close()
    xbmc.log("LTVPL: establishDataLocations Done")

xbmc.log("ltvpl data path: " + ADDON_USERDATA_FOLDER )

class Monitor(xbmc.Monitor):
    def __init__(self, server, cdService):
        """

        :type server: PL_Server
        """
        xbmc.Monitor.__init__(self)
        self.server = server #type: PL_Server
        self.cdService = cdService #type: Countdown.miniClient
        self.countdown_duration=None
        self.debugMode=None
        self.vacationMode=None
        self.stopcmd_active=None
        self.strAlarmtime=None
        self.preroll_time=None
        self.activationkey=None

    def onSettingsChanged(self):
        global LocalOperationFlag
        settingsChangedFlag=False
        #Local Settings

        # Countdown Duration
        countdown_duration = int(ADDON.getSetting('countdown_duration'))
        if self.countdown_duration != countdown_duration:
            self.countdown_duration=countdown_duration

        self.cdService.CountDownDuration = countdown_duration

        # Activation Key
        activationkey=ADDON.getSetting('activationkey')
        if self.activationkey != activationkey:
            self.activationkey=activationkey

        #Sever Settings
        LocalOperationFlag=True
        #Debug Mode
        debugMode = str(ADDON.getSetting('debugmode')).lower() == 'true'
        if self.debugMode != debugMode:
            self.debugMode=debugMode
            settingsChangedFlag=True

        #Vacation Mode
        vacationMode = str(ADDON.getSetting('vacationmode')).lower() == 'true'
        if self.vacationMode != vacationMode:
            self.vacationMode=vacationMode
            settingsChangedFlag = True

        #Daily Stop Command
        stopcmd_active = str(ADDON.getSetting('stopcmd_active')).lower() == 'true'
        strAlarmtime = str(ADDON.getSetting('alarmtime'))
        settingsChangedFlag = True
        myLog("onSettingsChanged Called", level=xbmc.LOGDEBUG)
        #


        # import web_pdb; web_pdb.set_trace()
        #Preroll Time
        preroll_time = int(ADDON.getSetting('preroll_time'))
        if self.preroll_time!= preroll_time:
            self.preroll_time=preroll_time
            settingsChangedFlag = True

        #Process Changed Settings
        try:
            if settingsChangedFlag:
                self.server.setSettings(vacationMode, debugMode, stopcmd_active, strAlarmtime, preroll_time=preroll_time)

        except ValueError as e:
            xbmcgui.Dialog().notification(LTVPL, e.message)

        LocalOperationFlag=False




def onServerSettingsChanged(setting, value):
    global LocalOperationFlag
    if LocalOperationFlag:
        return

    # import web_pdb; web_pdb.set_trace()
    if setting==PREROLLTIME:
        ADDON.setSetting(PREROLLTIME, str(value))
    elif setting==VACATIONMODE:
        ADDON.setSetting(VACATIONMODE, str(value))
    elif setting==DAILYSTOPCOMMAND:
        if value['stopcmd_active']:
            ADDON.setSetting('stopcmd_active', 'True')
            ADDON.setSetting('alarmtime', value['alarmtime'])
        else:
            ADDON.setSetting('stopcmd_active', 'False')



if __name__ == '__main__':
    from resources.PL_Server import PLSERVERTAG, isDialogActive, clearDialogActive
    cdService = None #type: Countdown.miniClient
    server = None #type: PL_Server

    if not isDialogActive(PLSERVERTAG):
        address = (ServerHost, ServerPort)
        establishDataLocations()
        server = PL_Server(address)
        debugMode = str(ADDON.getSetting('debugmode')).lower() == 'true'
        vacationMode = str(ADDON.getSetting('vacationmode')).lower() == 'true'
        server.startServer()
        server.addSettingsChangedEventHandler(onServerSettingsChanged)
        xbmc.log("Live TV Playlist Server Started...")

        while not server.server.isAlive():
            xbmc.sleep(500)

        # import Countdown
        try:
            countdown_duration= int(ADDON.getSetting('countdown_duration'))
            cdService = Countdown.StartCountdownService(ADDONID, clockstarttime=countdown_duration, abortChChange=server.dataSet.AbortChannelChangeOperation)
            xbmc.log("****Mini Client Service Successfully Started....")
        except: pass

        monitor = Monitor(server, cdService)
        monitor.waitForAbort()

        cdService.Stop()
        server.stopServer()
        del server
        del cdService
        del monitor
        clearDialogActive(PLSERVERTAG)
        xbmc.log("Live TV Playlist Server Stopped...")
