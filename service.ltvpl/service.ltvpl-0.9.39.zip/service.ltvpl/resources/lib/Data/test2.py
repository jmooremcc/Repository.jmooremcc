#

import time
import sys
import os
from datetime import datetime

print(datetime.now())
