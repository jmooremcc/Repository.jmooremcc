#
from datetime import datetime, timedelta
from PL_DataSet import PL_DataSet
from PlayListItem import PlayListItem
import time


ds=PL_DataSet()
plist=ds.GetPlayList()
for pl in plist:
    print(pl)

alarmtime=None
newpl=PlayListItem()

